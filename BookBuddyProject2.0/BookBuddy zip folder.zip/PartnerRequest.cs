﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBuddyProject2._0
{
    internal class PartnerRequest
    {
        public string FromUser { get; set; }
        public string ToUser { get; set; }
        public DateTime RequestDate { get; set; }
    }
}
