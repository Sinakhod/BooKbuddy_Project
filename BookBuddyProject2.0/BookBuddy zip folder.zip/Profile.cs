﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBuddyProject2._0
{
    internal class Profile
    {   
            public string FullName { get; set; }
            public string Year { get; set; }
            public string Course { get; set; }
            public string PreferredTime { get; set; }
    }
   

}

