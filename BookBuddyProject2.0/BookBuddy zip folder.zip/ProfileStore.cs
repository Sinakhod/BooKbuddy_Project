﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBuddyProject2._0
{
    internal class ProfileStore
    {
        public static List<Profile> Profiles = new List<Profile>();
    }
}
