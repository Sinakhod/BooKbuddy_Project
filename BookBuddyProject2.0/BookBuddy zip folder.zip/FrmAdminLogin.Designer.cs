﻿namespace BookBuddyProject2._0
{
    partial class FrmAdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbelCreateAccount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPassRecoAdminLogin = new System.Windows.Forms.Button();
            this.btnAdminLogin = new System.Windows.Forms.Button();
            this.chkShowPass = new System.Windows.Forms.CheckBox();
            this.txtPasswordAdminLogin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsernameAdminLogin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LbelCreateAccount
            // 
            this.LbelCreateAccount.AutoSize = true;
            this.LbelCreateAccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LbelCreateAccount.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbelCreateAccount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LbelCreateAccount.Location = new System.Drawing.Point(395, 422);
            this.LbelCreateAccount.Name = "LbelCreateAccount";
            this.LbelCreateAccount.Size = new System.Drawing.Size(115, 19);
            this.LbelCreateAccount.TabIndex = 47;
            this.LbelCreateAccount.Text = "Create Account ";
            this.LbelCreateAccount.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(372, 400);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(187, 19);
            this.label5.TabIndex = 46;
            this.label5.Text = "I Already Have an Account\r\n";
            // 
            // btnPassRecoAdminLogin
            // 
            this.btnPassRecoAdminLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPassRecoAdminLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPassRecoAdminLogin.FlatAppearance.BorderSize = 0;
            this.btnPassRecoAdminLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPassRecoAdminLogin.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPassRecoAdminLogin.ForeColor = System.Drawing.Color.White;
            this.btnPassRecoAdminLogin.Location = new System.Drawing.Point(337, 347);
            this.btnPassRecoAdminLogin.Name = "btnPassRecoAdminLogin";
            this.btnPassRecoAdminLogin.Size = new System.Drawing.Size(216, 35);
            this.btnPassRecoAdminLogin.TabIndex = 45;
            this.btnPassRecoAdminLogin.Text = "Forgot Password ";
            this.btnPassRecoAdminLogin.UseVisualStyleBackColor = false;
            this.btnPassRecoAdminLogin.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAdminLogin
            // 
            this.btnAdminLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnAdminLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdminLogin.FlatAppearance.BorderSize = 0;
            this.btnAdminLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdminLogin.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdminLogin.ForeColor = System.Drawing.Color.Black;
            this.btnAdminLogin.Location = new System.Drawing.Point(337, 294);
            this.btnAdminLogin.Name = "btnAdminLogin";
            this.btnAdminLogin.Size = new System.Drawing.Size(216, 35);
            this.btnAdminLogin.TabIndex = 44;
            this.btnAdminLogin.Text = "LOGIN";
            this.btnAdminLogin.UseVisualStyleBackColor = false;
            this.btnAdminLogin.Click += new System.EventHandler(this.button1_Click);
            // 
            // chkShowPass
            // 
            this.chkShowPass.AutoSize = true;
            this.chkShowPass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkShowPass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkShowPass.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowPass.ForeColor = System.Drawing.Color.Black;
            this.chkShowPass.Location = new System.Drawing.Point(442, 248);
            this.chkShowPass.Name = "chkShowPass";
            this.chkShowPass.Size = new System.Drawing.Size(135, 23);
            this.chkShowPass.TabIndex = 43;
            this.chkShowPass.Text = "Show Password ";
            this.chkShowPass.UseVisualStyleBackColor = true;
            this.chkShowPass.CheckedChanged += new System.EventHandler(this.chkShowPass_CheckedChanged);
            // 
            // txtPasswordAdminLogin
            // 
            this.txtPasswordAdminLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.txtPasswordAdminLogin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPasswordAdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordAdminLogin.Location = new System.Drawing.Point(334, 214);
            this.txtPasswordAdminLogin.Multiline = true;
            this.txtPasswordAdminLogin.Name = "txtPasswordAdminLogin";
            this.txtPasswordAdminLogin.PasswordChar = '•';
            this.txtPasswordAdminLogin.Size = new System.Drawing.Size(216, 28);
            this.txtPasswordAdminLogin.TabIndex = 42;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(334, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 19);
            this.label3.TabIndex = 41;
            this.label3.Text = "Password ";
            // 
            // txtUsernameAdminLogin
            // 
            this.txtUsernameAdminLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.txtUsernameAdminLogin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsernameAdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsernameAdminLogin.Location = new System.Drawing.Point(334, 153);
            this.txtUsernameAdminLogin.Multiline = true;
            this.txtUsernameAdminLogin.Name = "txtUsernameAdminLogin";
            this.txtUsernameAdminLogin.Size = new System.Drawing.Size(216, 28);
            this.txtUsernameAdminLogin.TabIndex = 40;
            this.txtUsernameAdminLogin.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(334, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 19);
            this.label2.TabIndex = 39;
            this.label2.Text = "Username (@mywsu.ac.za)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(359, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 31);
            this.label1.TabIndex = 38;
            this.label1.Text = "Ready to Login ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BookBuddyProject2._0.Properties.Resources.resize_the_Book_Budd;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 440);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // FrmAdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(690, 544);
            this.Controls.Add(this.LbelCreateAccount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnPassRecoAdminLogin);
            this.Controls.Add(this.btnAdminLogin);
            this.Controls.Add(this.chkShowPass);
            this.Controls.Add(this.txtPasswordAdminLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUsernameAdminLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmAdminLogin";
            this.Text = "FrmAdminLogin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LbelCreateAccount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnPassRecoAdminLogin;
        private System.Windows.Forms.Button btnAdminLogin;
        private System.Windows.Forms.CheckBox chkShowPass;
        private System.Windows.Forms.TextBox txtPasswordAdminLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsernameAdminLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}